# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 16:28:18 2018

@author: Sean
"""
import sys
import os
from PyQt5 import QtGui, QtCore

from numpy import arange, sin, pi
import GuiTestFun
import numpy as np
from operator import itemgetter
import pyqtgraph as pg
pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')
############################################################################
################             Main Window              ######################
############################################################################


class MW(QtGui.QMainWindow):

    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.create_main_frame()
        self.starting = True
        self.starting2 = True
        self.resize(1500,900)
        self.setWindowTitle("iFAMS v. 5.1")
        QtGui.QApplication.setStyle(QtGui.QStyleFactory.create("Cleanlooks"))
        self.setWindowIcon(QtGui.QIcon('CapI.png'))

        
        #File menu apps
        self.file_menu = QtGui.QMenu('&File', self)
        self.file_menu.addAction('Load Spectrum',self.MSplot)
        self.file_menu.addAction('Save Fourier Spectrum',self.SaveFT)
        self.file_menu.addAction('Save Envelope Reconstructions',self.SaveEnvel)
        self.file_menu.addAction('&Quit', self.fileQuit,
                                 QtCore.Qt.CTRL + QtCore.Qt.Key_Q)
        self.menuBar().addMenu(self.file_menu)
        
        #Analysis Menu
        self.analysis_menu = QtGui.QMenu('&Analysis',self)
        self.analysis_menu.addAction('Fourier Transform',self.FourierPlot)
        self.analysis_menu.addAction('Calculate Charge States and Subunit Mass',self.CharAndSubCalc)
        self.analysis_menu.addAction('Manually Enter Charge States/Subunit Mass', self.change)
        self.analysis_menu.addAction('Reconstruct Envelope Functions', self.reconstruct)
        self.analysis_menu.addAction('Fourier Filter',self.FFTFil)         
        self.menuBar().addMenu(self.analysis_menu)
        
        self.tools_menu = QtGui.QMenu('&Tools',self)
        self.model_spectrum_menu = self.tools_menu.addMenu('&Model Spectrum Generator')
        self.model_spectrum_menu.addAction('single charge state Gaussian',self.SinGau)
        self.model_spectrum_menu.addAction('multiple charge state Gaussian',self.MulGau)
        self.tools_menu.addAction('Compare two Fourier Spectra',self.SquDef)
        self.tools_menu.addAction('Calculate Subunit Statistics', self.statCalc)
        self.menuBar().addMenu(self.tools_menu)

    def create_main_frame(self):
        self.main_frame = QtGui.QWidget()
        MW.plotMS = pg.PlotWidget()
        MW.plotFT = pg.PlotWidget()
        MW.FT1 = pg.PlotWidget()
        MW.FT2 = pg.PlotWidget()
        MW.MIXFT = pg.PlotWidget()
        MW.SquareD = pg.PlotWidget()
        
        MW.plotMS.setParent(self.main_frame)
        MW.plotFT.setParent(self.main_frame)
        MW.FT1.setParent(self.main_frame)
        MW.FT2.setParent(self.main_frame)
        MW.MIXFT.setParent(self.main_frame)
        MW.SquareD.setParent(self.main_frame)
        
        MW.plotMS.hide()
        MW.plotFT.hide()
        MW.FT1.hide()
        MW.FT2.hide()
        MW.MIXFT.hide()
        MW.SquareD.hide()
        
        MW.plotMS.addLegend()
        MW.MIXFT.addLegend()

############ Stats Box ###############################         
        self.status_info_tag = QtGui.QLabel(self.main_frame)
        self.status_info_tag.setText('status/information')
        self.status_info_tag.setFixedHeight(50)
        self.DiaBox = QtGui.QTextEdit()
        self.DiaBox.setFixedHeight(100)
############ Stats Box ############################### 

###############Fourier Transform Placed Apps#############        
        self.lowendtext = QtGui.QTextEdit(self.main_frame)
        self.lowendtext.setFixedHeight(30)
        self.lowendtext.setTabChangesFocus(True)
        self.pctpkhttext = QtGui.QTextEdit(self.main_frame)
        self.pctpkhttext.setFixedHeight(30)
        self.pctpkhttext.setTabChangesFocus(True)        
        self.deltatext = QtGui.QTextEdit(self.main_frame)
        self.deltatext.setFixedHeight(30)
        self.deltatext.setTabChangesFocus(True)
        self.lowendtexttag = QtGui.QLabel(self.main_frame)
        self.lowendtexttag.setText('Minimum Frequency Used (default 0.001)')
        self.lowendtexttag.setFixedHeight(30)
        self.pctpkhttexttag = QtGui.QLabel(self.main_frame)
        self.pctpkhttexttag.setText('Min FFT Peak Height % (default 10%)')
        self.pctpkhttexttag.setFixedHeight(30)
        self.deltatexttag = QtGui.QLabel(self.main_frame)
        self.deltatexttag.setText('Delta (default 5 FFT points)')
        self.deltatexttag.setFixedHeight(30)
        self.button1 = QtGui.QPushButton('Update These Values')
        self.button1.clicked.connect(self.Recalculate)
        self.button1.setFixedHeight(30)
        self.minnoi_tag = QtGui.QLabel(self.main_frame)
        self.minnoi_tag.setFixedHeight(30)
        self.minnoi_tag.setText("Minimum Noise Frequency")
        self.minnoi = QtGui.QTextEdit(self.main_frame)
        self.minnoi.setTabChangesFocus(True)        
        self.minnoi.setFixedHeight(30)
        self.maxnoi_tag = QtGui.QLabel(self.main_frame)
        self.maxnoi_tag.setFixedHeight(30)
        self.maxnoi_tag.setText("Maximum Noise Frequency")
        self.maxnoi = QtGui.QTextEdit(self.main_frame)
        self.maxnoi.setTabChangesFocus(True)        
        self.maxnoi.setFixedHeight(30)
        self.button2 = QtGui.QPushButton('Calculate Noise Statistics')
        self.button2.clicked.connect(self.FourierNoise)
        self.button2.setFixedHeight(30)
        
        self.lowendtext.hide()
        self.pctpkhttext.hide()
        self.deltatext.hide()
        self.lowendtexttag.hide()
        self.pctpkhttexttag.hide()
        self.deltatexttag.hide()
        self.button1.hide()
        self.minnoi_tag.hide()
        self.minnoi.hide()
        self.maxnoi_tag.hide()
        self.maxnoi.hide()
        self.button2.hide()
###############Fourier Transform Placed Apps#############
 
############# Fourier Spectra Comparison################## 
        self.LowNumbertag = QtGui.QLabel(self.main_frame)
        self.LowNumbertag.setText('Mim data points')
        self.LowNumbertag.setFixedHeight(30)
        self.LowNumber = QtGui.QTextEdit(self.main_frame)
        self.LowNumber.setFixedHeight(30)
        self.LowNumber.setTabChangesFocus(True)
        self.HighNumbertag = QtGui.QLabel(self.main_frame)
        self.HighNumbertag.setText('Max data points')
        self.HighNumbertag.setFixedHeight(30)
        self.HighNumber = QtGui.QTextEdit(self.main_frame)
        self.HighNumber.setFixedHeight(30)
        self.HighNumber.setTabChangesFocus(True)
        self.LowPertag = QtGui.QLabel(self.main_frame)
        self.LowPertag.setText('Percentage Spectrum 1')
        self.LowPertag.setFixedHeight(30)
        self.LowPer = QtGui.QTextEdit(self.main_frame)
        self.LowPer.setFixedHeight(30)
        self.LowPer.setTabChangesFocus(True)
        self.HighPertag = QtGui.QLabel(self.main_frame)
        self.HighPertag.setText('Percentage Spectrum 2')
        self.HighPertag.setFixedHeight(30)
        self.HighPer = QtGui.QTextEdit(self.main_frame)
        self.HighPer.setFixedHeight(30)
        self.HighPer.setTabChangesFocus(True)
        self.button3 = QtGui.QPushButton('load first spectrum')
        self.button3.clicked.connect(self.FirstSpectrum)
        self.button3.setFixedHeight(30)
        self.button4 = QtGui.QPushButton('load second spectrum')
        self.button4.clicked.connect(self.SecondSpectrum)
        self.button4.setFixedHeight(30)
        self.button5 = QtGui.QPushButton('load mix spectrum')
        self.button5.clicked.connect(self.MixSpectrum)
        self.button5.setFixedHeight(30)
        self.button6 = QtGui.QPushButton('recalculate')
        self.button6.clicked.connect(self.recalcuate2)
        self.button6.setFixedHeight(30)
        
        self.LowNumber.hide()
        self.HighNumber.hide()
        self.button3.hide()
        self.button4.hide()
        self.button5.hide()
        self.HighNumbertag.hide()
        self.LowNumbertag.hide()
        self.LowPertag.hide()
        self.LowPer.hide()
        self.HighPertag.hide()
        self.HighPer.hide()
        self.button6.hide()
############# Fourier Spectra Comparison##################        

############# Manual Charge state and submass calc wig #######
        self.inputlowchar = QtGui.QTextEdit()
        self.inputlowchar.setFixedHeight(30)
        self.inputlowchar.setTabChangesFocus(True)
        self.inputhighchar = QtGui.QTextEdit()
        self.inputhighchar.setFixedHeight(30)
        self.inputhighchar.setTabChangesFocus(True)
        self.inputSM = QtGui.QTextEdit()
        self.inputSM.setFixedHeight(30)
        self.inputSM.setTabChangesFocus(True)
        self.inputlowchartag = QtGui.QLabel()
        self.inputlowchartag.setText('Low charge state')
        self.inputlowchartag.setFixedHeight(30)
        self.inputhighchartag = QtGui.QLabel()
        self.inputhighchartag.setText('high charge state')
        self.inputhighchartag.setFixedHeight(30)
        self.inputSMtag = QtGui.QLabel()
        self.inputSMtag.setText('Sub-Unit mass (number)')
        self.inputSMtag.setFixedHeight(30)
        self.button7 = QtGui.QPushButton('Enter')
        self.button7.clicked.connect(self.inputs)
        self.button7.setFixedHeight(30)
        
        self.inputlowchar.hide()
        self.inputhighchar.hide()
        self.inputSM.hide()
        self.inputlowchartag.hide()
        self.inputhighchartag.hide()
        self.inputSMtag.hide()
        self.button7.hide()
############# Manual Charge state and submass calc wig #######

        MW.RefNum = 0
        MW.starting = True
        MW.starting2 = True
        
        vbox = QtGui.QGridLayout()
        vbox.setRowStretch(0,2)
        vbox.setRowStretch(1,2)
        vbox.setRowStretch(2,2)
        vbox.setRowStretch(3,2)
        vbox.setRowStretch(4,2)
        vbox.setRowStretch(5,2)
        vbox.setRowStretch(6,2)
        vbox.setRowStretch(7,1)
        vbox.setRowStretch(8,2)
        vbox.setRowStretch(9,1)
        vbox.setRowStretch(10,1)
        vbox.setRowStretch(11,1)
        vbox.setRowStretch(12,1)
        vbox.setRowStretch(13,1)
        vbox.setRowStretch(14,1)
        vbox.setRowStretch(15,1)
        vbox.setColumnStretch(0,10)
        vbox.setColumnStretch(1,1)
        vbox.setColumnStretch(2,10)
        vbox.setColumnStretch(3,1)

############ Plots ####################################
        vbox.addWidget(MW.plotMS, 0,0,6,2)
        vbox.addWidget(MW.plotFT, 0,2,6,2)
        vbox.addWidget(MW.FT1,0,0,3,2)
        vbox.addWidget(MW.FT2,3,0,3,2)
        vbox.addWidget(MW.MIXFT,0,2,3,2)
        vbox.addWidget(MW.SquareD,3,2,3,2)
############ Plots ####################################

############ Stats Box ###############################        
        vbox.addWidget(self.status_info_tag,7,0)
        vbox.addWidget(self.DiaBox,8,0,1,1)
############ Stats Box ###############################
        
###############Fourier Transform Placed Apps#############
        vbox.addWidget(self.lowendtexttag,9,0)
        vbox.addWidget(self.lowendtext,10,0)
        vbox.addWidget(self.pctpkhttexttag,11,0)
        vbox.addWidget(self.pctpkhttext,12,0)
        vbox.addWidget(self.deltatexttag,13,0)
        vbox.addWidget(self.deltatext,14,0)
        vbox.addWidget(self.button1,15,0)
        vbox.addWidget(self.minnoi_tag,7,2)
        vbox.addWidget(self.minnoi,8,2)
        vbox.addWidget(self.maxnoi_tag,9,2)
        vbox.addWidget(self.maxnoi,10,2)
        vbox.addWidget(self.button2,11,2)
 ###############Fourier Transform Placed Apps#############

############# Fourier Spectra Comparison##################       
        vbox.addWidget(self.LowNumber,10,0)
        vbox.addWidget(self.HighNumber,12,0)
        vbox.addWidget(self.LowNumbertag,9,0)
        vbox.addWidget(self.HighNumbertag,11,0)
        vbox.addWidget(self.button3,13,0)
        vbox.addWidget(self.button4,14,0)
        vbox.addWidget(self.button5,15,0)
        vbox.addWidget(self.LowPertag,9,2)
        vbox.addWidget(self.LowPer,10,2)
        vbox.addWidget(self.HighPertag,11,2)
        vbox.addWidget(self.HighPer,12,2)
        vbox.addWidget(self.button6,13,2)
############# Fourier Spectra Comparison#################

############# Manual Charge state and submass calc ##########
        vbox.addWidget(self.inputlowchar,10,0)
        vbox.addWidget(self.inputhighchar,12,0)
        vbox.addWidget(self.inputSM,14,0)
        vbox.addWidget(self.inputlowchartag,9,0)
        vbox.addWidget(self.inputhighchartag,11,0)
        vbox.addWidget(self.inputSMtag,13,0)
        vbox.addWidget(self.button7,15,0)
 ############# Manual Charge state and submass calc ##########       
        
        self.main_frame.setLayout(vbox)
        self.setCentralWidget(self.main_frame)

        
    def home(self):
        self.toolbar.home()
    def zoom(self):
        self.toolbar.zoom()
    def pan(self):
        self.toolbar.pan()
    def back(self):
        self.toolbar.back()
    
    def fileQuit(self):
        self.close()

    def closeEvent(self, event):
        
        reply = QtGui.QMessageBox.question(self, 'Message',
            "Are you sure you want to quit?", QtGui.QMessageBox.Yes |
            QtGui.QMessageBox.No, QtGui.QMessageBox.No)

        if reply == QtGui.QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
            
    def ManCalcWigHide(self): # A function that hides all of the manual calculation widget
        self.inputlowchar.hide()
        self.inputhighchar.hide()
        self.inputSM.hide()
        self.inputlowchartag.hide()
        self.inputhighchartag.hide()
        self.inputSMtag.hide()
        self.button7.hide()
        
    def FourierWigShow(self): # A function that displays all of the Fourier widgets
        self.lowendtext.show()
        self.pctpkhttext.show()
        self.deltatext.show()
        self.lowendtexttag.show()
        self.pctpkhttexttag.show()
        self.deltatexttag.show()
        self.button1.show()
        self.minnoi_tag.show()
        self.minnoi.show()
        self.maxnoi_tag.show()
        self.maxnoi.show()
        self.button2.show()
    
    def FourierWigHide(self):# a function that hides the Fourier Widget
        self.lowendtext.hide()
        self.pctpkhttext.hide()
        self.deltatext.hide()
        self.lowendtexttag.hide()
        self.pctpkhttexttag.hide()
        self.deltatexttag.hide()
        self.button1.hide()
        self.minnoi_tag.hide()
        self.minnoi.hide()
        self.maxnoi_tag.hide()
        self.maxnoi.hide()
        self.button2.hide()
    
    def FourierCompWigShow(self): #a function that displays the comparative widgets
        self.LowNumber.show()
        self.HighNumber.show()
        self.button3.show()
        self.button4.show()
        self.button5.show()
        self.HighNumbertag.show()
        self.LowNumbertag.show()
        self.LowPertag.show()
        self.LowPer.show()
        self.HighPertag.show()
        self.HighPer.show()
        self.button6.show()
    
    def FourierCompWigHide(self):#a function that hides the comparative widgets
        self.LowNumber.hide()
        self.HighNumber.hide()
        self.button3.hide()
        self.button4.hide()
        self.button5.hide()
        self.HighNumbertag.hide()
        self.LowNumbertag.hide()
        self.LowPertag.hide()
        self.LowPer.hide()
        self.HighPertag.hide()
        self.HighPer.hide()
        self.button6.hide()
        MW.FT1.hide()
        MW.FT2.hide()
        MW.MIXFT.hide()
        MW.SquareD.hide()
        
    def HideMainSpec(self):# a function that hides the main plots for other functions
        self.plotMS.hide()
        self.plotFT.hide()
        
    def MSplot(self):# A function that plots the mass spectrum
        self.FourierCompWigHide()
        self.plotMS.clear()
        MW.xdata,MW.ydata,self.namebase = GuiTestFun.plot(self)
        self.yfull,MW.expandedspan,MW.xnew,MW.ftspacing,MW.paddedxnew,MW.ynew = GuiTestFun.plot_function(MW.xdata,MW.ydata)
        MW.plotMS.plot(MW.xdata,MW.ydata, pen ='k',symbol=None)
        MW.plotMS.setLabel('left','abundance')
        MW.plotMS.setLabel('bottom', 'm/z')
        MW.plotMS.show()
        
      
    def FourierPlot(self): #A function that Fourier transfroms the mass spectrum, a plots the fourier transform next to th
        MW.plotFT.clear()
        self.maxfreq = GuiTestFun.maxfreq(self,self.yfull,MW.expandedspan)
        MW.ftx,MW.ABFT,MW.FT = GuiTestFun.Fourier(self,self.maxfreq,self.yfull)
        MW.refmaxtab = GuiTestFun.findmax(MW.expandedspan,MW.ABFT,MW.ftx,0.001,5,10)
        MW.plotFT.plot(MW.ftx,MW.ABFT,pen='k',symbol=None)
        MW.plotFT.plot(np.array(MW.refmaxtab)[:,0], np.array(MW.refmaxtab)[:,1],
                       pen=None, symbolPen='r', symbolBrush='r', symbol = 'o')
        MW.plotFT.setLabel('left','amplitude')
        MW.plotFT.setLabel('bottom', 'frequency')
        MW.plotFT.show()
        self.FourierWigShow()
        self.FourierCompWigHide()
        self.ManCalcWigHide()
    
    def Recalculate(self): #A Fuction to estimate peak maxima in your spectra
        lowend = float(str(self.lowendtext.toPlainText()))
        pctpkht = float(str(self.pctpkhttext.toPlainText()))
        delta = int(str(self.deltatext.toPlainText()))
        MW.refmaxtab = GuiTestFun.findmax(MW.expandedspan,MW.ABFT,MW.ftx,lowend,delta,pctpkht)
        self.plotDots()        
        
    def plotDots(self):#This plots the dots in the spectrum
        MW.plotFT.clear()
        MW.plotFT.plot(MW.ftx,MW.ABFT,pen='k',symbol=None)
        MW.plotFT.plot(np.array(MW.refmaxtab)[:,0], np.array(MW.refmaxtab)[:,1],
                       pen=None, symbolPen='b', symbolBrush='b', symbol = 'o')
        MW.plotFT.setLabel('left','amplitude')
        MW.plotFT.setLabel('bottom', 'frequency')
        MW.plotFT.show()
        
    
    def CharAndSubCalc(self): #calculates an initial estimate for the spacing of the group of evenly-spaced FFT
        # spectrum peaks that probably aren't overtone peaks
        newcalcX = []
        newcalcY = []
        if len(MW.refmaxtab) < 3:
            self.DiaBox.append('not enough charge states!')
            exit
        else:
            MW.refmaxtabCalc = np.array(MW.refmaxtab)
            self.numchar = GuiTestFun.spacing(self,MW.refmaxtab)
            self.omega = GuiTestFun.omega(MW.refmaxtab,self.numchar)
            self.chargestates, MW.chargestatesr = GuiTestFun.charge(MW.refmaxtab,self.numchar,self.omega)
            for i in range (0,len(MW.chargestatesr)):
                newcalcX.append(MW.refmaxtabCalc[i,0])
                newcalcY.append(MW.refmaxtabCalc[i,1])
            MW.plotFT.plot(newcalcX,newcalcY,pen=None, symbolPen='g', symbolBrush='g', symbol = 'o')
            MW.submass, self.stdevmass  = GuiTestFun.subunit(MW.refmaxtab,self.numchar,self.omega,self.chargestates,
                                                             self.chargestatesr,self.ftx,self.ABFT)
            roundedsubmass = str(round(MW.submass,3))
            roundedstdevmass = str(round(self.stdevmass,3))
            plusminus = ' +- '
            massplusminus = roundedsubmass + plusminus + roundedstdevmass
            self.DiaBox.append("The average Sub-unit mass is " + massplusminus)
            self.chargestateints = [int(MW.chargestatesr[i]) for i in range(0,len(MW.chargestatesr))]        
            self.DiaBox.append("The charge states are " + str(self.chargestateints))
            self.DiaBox.append("Rounded from " + str(self.chargestates))
    
    def FourierNoise (self): #the calculates the white noise in the fourier spectrum
        
        minnoi = int(np.floor(float(str(self.minnoi.toPlainText()))*2*MW.expandedspan))
        maxnoi = int(np.floor(float(str(self.maxnoi.toPlainText()))*2*MW.expandedspan))
        
        ##################### Real Noise Average #######################
        MW.realnoiseavg = GuiTestFun.FTRealNoiAvg(minnoi,maxnoi,MW.FT)        
        realnoiseAvgtag = "average Re(noise) is "
        realnoiseavgFin = realnoiseAvgtag + str(MW.realnoiseavg)
        self.DiaBox.append(realnoiseavgFin) 
        ##################### Real Noise Average #######################
        
        ##################### Imag Noise Average #######################
        MW.imagnoiseavg = GuiTestFun.FTImagNoiAvg(minnoi,maxnoi,MW.FT)        
        imagnoiavg = "average Im(noise) is "
        imagnoiavg2 = imagnoiavg + str(MW.imagnoiseavg)
        self.DiaBox.append(imagnoiavg2)
        ##################### Imag Noise Average #######################
        
        ##################### Real Noise Stdev ######################### 
        MW.realnoisestdev = GuiTestFun.FTRealNoiStdev(minnoi,maxnoi,MW.FT)        
        realnoisvd = "stdev of Re(noise) is "
        realnoisvd2 = realnoisvd + str(MW.realnoisestdev)
        self.DiaBox.append(realnoisvd2)
        ##################### Real Noise Stdev #########################
        
        ##################### Imag Noise Stdev #########################
        MW.imagnoisestdev = GuiTestFun.FTImagNoiStdev(minnoi,maxnoi,MW.FT)        
        imagenoisvd = "stdev of Im(noise) is "
        imagenoisvd2 = imagenoisvd + str(MW.imagnoisestdev)
        self.DiaBox.append(imagenoisvd2)
        ##################### Imag Noise Stdev #########################
        
    
    def reconstruct(self): #this function will window the fourier spectrum to reconstruct the peak
        MW.chargestateints = [int(MW.chargestatesr[i]) for i in range(0,len(MW.chargestatesr))]
        MW.ABIFT,MW.ABIFTnoise,MW.ABIFTintegral,MW.msintegral = GuiTestFun.IFTEnvelope(MW.chargestatesr,
                                                                                       MW.expandedspan,
                                                                                       MW.submass,MW.ftx,MW.ftspacing,
                                                                                       MW.FT,MW.paddedxnew,MW.xnew,
                                                                                       MW.ynew,MW.ydata,
                                                                                       MW.realnoisestdev,
                                                                                       MW.imagnoisestdev)
        colors = ['b','g','r','c','m','y','k','b','g','r','c','m','y','k','b','g','r','c','m','y','k','b','g','r','c',
                  'm','y','k','b','g','r','c','m','y','k']
        for i in range (0,len(MW.chargestateints)):
            MW.plotMS.plot(MW.xnew,MW.ABIFT[i][0:int(len(MW.xnew))],
                           pen=colors[i], symbol=None, name = MW.chargestateints[i])
            MW.xnewfornoise = []
            MW.ABIFTplusnoise = []
            MW.ABIFTminusnoise = [] 
            for j in range(0,len(MW.ABIFT[i])):
                if j%50 == 0:                
                    MW.ABIFTnoise[i][int(j/50)] = MW.ABIFTnoise[i][int(j/50)]
            for m in range(0,len(MW.ABIFTnoise[i])):                 
                MW.xnewfornoise.append(self.paddedxnew[int(50*m)])
                MW.ABIFTplusnoise.append(MW.ABIFT[i][int(50*m)]+MW.ABIFTnoise[i][m])
                MW.ABIFTminusnoise.append(MW.ABIFT[i][int(50*m)]-MW.ABIFTnoise[i][m])
            MW.plotMS.plot(MW.xnewfornoise[0:int(len(MW.xnew)/50)],MW.ABIFTplusnoise[0:int(len(MW.xnew)/50)],
                           pen = pg.mkPen(color = colors[i], symbol = None, width=3, style=QtCore.Qt.DashLine))
            MW.plotMS.plot(MW.xnewfornoise[0:int(len(MW.xnew)/50)],MW.ABIFTminusnoise[0:int(len(MW.xnew)/50)],
                           pen = pg.mkPen(color = colors[i], symbol = None, width=3, style=QtCore.Qt.DashLine))

        
        
        
    def SaveFT(self): # saves the FT spectrum
        ftstring = "FT"
        ftfilename = self.namebase + ftstring + ".csv"
        ftarrayforexport = np.transpose([MW.ftx,MW.ABFT])        
        np.savetxt(ftfilename,ftarrayforexport,fmt='%10.6f',delimiter=',')#outputs the FFT data to its own file
        self.DiaBox.append(ftfilename + " was Exported")
    
    def SaveEnvel(self): # saves the envelope function
        for i in range (0,len(MW.chargestatesr)):
            ifftfilename = 0
            ifftfilenamenoise = 0
            iftstring = "IFFT"
            ifftfilename = self.namebase + iftstring + str(MW.chargestateints[i]) + ".csv"
            ifftforexport = 0
            ifftforexport = np.transpose([MW.xnew,MW.ABIFT[i][0:int(len(MW.xnew))]])
            np.savetxt(ifftfilename,ifftforexport,fmt='%10.6f', delimiter=',') #outputs each charge-state-specific
            # spectrum to its own csv file
            MW.xnewfornoise = []
            MW.ABIFTplusnoise = []
            MW.ABIFTminusnoise = []
            for j in range(0,len(MW.ABIFT[i])):
                if j%50 == 0:
                    MW.ABIFTnoise[i][int(j/50)] = MW.ABIFTnoise[i][int(j/50)]
            for m in range(0,len(MW.ABIFTnoise[i])):
                MW.xnewfornoise.append(self.paddedxnew[int(50*m)])
                MW.ABIFTplusnoise.append(MW.ABIFT[i][int(50*m)]+MW.ABIFTnoise[i][m])
                MW.ABIFTminusnoise.append(MW.ABIFT[i][int(50*m)]-MW.ABIFTnoise[i][m])
            ifftfilenamenoise = self.namebase + iftstring + str(MW.chargestateints[i]) + "noise.csv"                
            ifftnoiseforexport = 0                
            ifftnoiseforexport = np.transpose([MW.xnewfornoise[0:int(len(MW.xnew)/50)],
                                               MW.ABIFTminusnoise[0:int(len(MW.xnew)/50)],
                                               MW.ABIFTplusnoise[0:int(len(MW.xnew)/50)]])
            np.savetxt(ifftfilenamenoise,ifftnoiseforexport,
                       fmt='%10.6f',header='m/z,abundance-noise,abundance+noise',delimiter=',')

    def SquDef(self): #rearranges the tiles on the main page
        self.FourierWigHide()
        self.HideMainSpec()
        self.FourierCompWigShow()
        self.ManCalcWigHide()

        
    def FirstSpectrum(self): #Loads the first spectrum for comparison

###### Loads Spectrum and calls x and y values x1 and y1 ################################
        name = QtGui.QFileDialog.getOpenFileName(self, 'Open File')
        namestr = str(name[0])
        self.namebase = os.path.splitext(namestr)[0]
        rawdata = open(name[0],'r')
        fileloadedtxt = 'loaded ' + namestr
        self.DiaBox.append(fileloadedtxt)
        if namestr.endswith('.csv'):
            MW.x1,MW.y1=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = ',')
        elif namestr.endswith('.txt'):
            MW.x1,MW.y1=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = '\t')
        else:
            fileloaderrortxt = fileloadedtxt + ' is not .csv or .txt'
            self.DiaBox.append(fileloaderrortxt)
            exit
        MW.FT1.clear()
        MW.yedit1 = []
        MW.xedit1 = []
        lowNumber = int(str(self.LowNumber.toPlainText()))
        HighNumber = int(str(self.HighNumber.toPlainText()))
        for i in range(lowNumber,HighNumber):
            MW.yedit1.append(MW.y1[i])
            MW.xedit1.append(MW.x1[i])
        np.array(MW.yedit1)
        np.array(MW.xedit1)
        MW.yedit1max = np.max(MW.yedit1)
        for i in range(0,len(MW.yedit1)):
            MW.yedit1[i] = MW.yedit1[i]/MW.yedit1max
        
        MW.FT1.plot(MW.xedit1,MW.yedit1,pen='k',symbol=None)
        MW.FT1.show()
        
    def SecondSpectrum(self): #loads the second spectrum for the comparison

###### Loads Spectrum and calls x and y values x1 and y1 ################################
        name = QtGui.QFileDialog.getOpenFileName(self, 'Open File')
        namestr = str(name[0])
        self.namebase = os.path.splitext(namestr)[0]
        rawdata = open(name[0],'r')
        fileloadedtxt = 'loaded ' + namestr
        self.DiaBox.append(fileloadedtxt)
        if namestr.endswith('.csv'):
            MW.x2,MW.y2=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = ',')
        elif namestr.endswith('.txt'):
            MW.x2,MW.y2=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = '\t')
        else:
            fileloaderrortxt = fileloadedtxt + ' is not .csv or .txt'
            self.DiaBox.append(fileloaderrortxt)
            exit
        MW.FT2.clear()
        MW.yedit2 = []
        MW.xedit2 = []
        lowNumber = int(str(self.LowNumber.toPlainText()))
        HighNumber = int(str(self.HighNumber.toPlainText()))
        for i in range(lowNumber,HighNumber):
            MW.yedit2.append(MW.y2[i])
            MW.xedit2.append(MW.x2[i])
        np.array(MW.yedit2)
        np.array(MW.xedit2)
        MW.yedit2max = np.max(MW.yedit2)
        for i in range(0,len(MW.yedit2)):
            MW.yedit2[i] = MW.yedit2[i]/MW.yedit2max
        
        MW.FT2.plot(MW.xedit2,MW.yedit2,pen='k',symbol=None)
        MW.FT2.show()
    
    def MixSpectrum(self): #loads the third spectrum for the comparison

###### Loads Spectrum and calls x and y values x2 and y2 ################################
        name = QtGui.QFileDialog.getOpenFileName(self, 'Open File')
        namestr = str(name[0])
        self.namebase = os.path.splitext(namestr)[0]
        rawdata = open(name[0],'r')
        fileloadedtxt = 'loaded ' + namestr
        self.DiaBox.append(fileloadedtxt)
        if namestr.endswith('.csv'):
            MW.x3,MW.y3=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = ',')
        elif namestr.endswith('.txt'):
            MW.x3,MW.y3=np.loadtxt (rawdata,
                   unpack = True,
                   delimiter = '\t')
        else:
            fileloaderrortxt = fileloadedtxt + ' is not .csv or .txt'
            self.DiaBox.append(fileloaderrortxt)
            exit
        MW.MIXFT.clear()
        MW.yedit3 = []
        MW.xedit3 = []
        lowNumber = int(str(self.LowNumber.toPlainText()))
        HighNumber = int(str(self.HighNumber.toPlainText()))
        for i in range(lowNumber,HighNumber):
            MW.yedit3.append(MW.y3[i])
            MW.xedit3.append(MW.x3[i])
        np.array(MW.yedit3)
        np.array(MW.xedit3)
        MW.yedit3max = np.max(MW.yedit3)
        for i in range(0,len(MW.yedit3)):
            MW.yedit3[i] = MW.yedit3[i]/MW.yedit3max
        
        MW.MIXFT.plot(MW.xedit3,MW.yedit3,pen='k',symbol=None)
        MW.MIXFT.show()
        self.analyzer2()
        
    def analyzer2(self): #does the analysis for the comparison

        MW.AvNumLilfinal, MW.DevFinal = GuiTestFun.analyzer2(MW.yedit1,MW.yedit2,MW.yedit3)
        CompareFile = np.transpose([MW.xedit3,MW.AvNumLilfinal])
        np.savetxt("CompareFile.csv", CompareFile, delimiter=',')
        MW.MIXFT.plot(MW.xedit3,MW.AvNumLilfinal,pen='b',symbol=None)
        MW.xrange = np.arange(1,101)
        SquarFile = np.transpose([MW.xrange, MW.DevFinal])
        np.savetxt("SquareFile.csv",SquarFile,delimiter=',')
        MW.SquareD.plot(MW.xrange,MW.DevFinal,pen='k',symbol=None)
        MW.SquareD.show()
    
    def recalcuate2(self): #Recalculate the comparison
        in1 = int(str(self.LowPer.toPlainText()))
        in2 = int(str(self.HighPer.toPlainText()))
        MW.MIXFT.clear()
        MW.AvNumLilfinal = GuiTestFun.ManCompare(MW.yedit1,MW.yedit2,in1,in2)
        MW.MIXFT.plot(MW.xedit3,MW.yedit3,pen='k',symbol=None)
        MW.MIXFT.plot(MW.xedit3,MW.AvNumLilfinal,pen='b',symbol=None)
        MW.MIXFT.show()
    
    def inputs(self): # the input for the
        lowcharge = int(str(self.inputlowchar.toPlainText())) 
        highcharge = int(str(self.inputhighchar.toPlainText()))
        MW.submass = float(str(self.inputSM.toPlainText()))
        MW.chargestatesr = np.arange(lowcharge,highcharge+1)
        MW.refmaxtab = GuiTestFun.inputmax(MW.chargestatesr,MW.submass,MW.ABFT,MW.ftx)
        MW.plotDots(self)
        MW.CharAndSubCalc(self)


        
############# extra windows ######################
    def change(self):
        self.lowendtext.hide()
        self.pctpkhttext.hide()
        self.deltatext.hide()
        self.lowendtexttag.hide()
        self.pctpkhttexttag.hide()
        self.deltatexttag.hide()
        self.button1.hide()
        self.inputlowchar.show()
        self.inputhighchar.show()
        self.inputSM.show()
        self.inputlowchartag.show()
        self.inputhighchartag.show()
        self.inputSMtag.show()
        self.button7.show()
        
    def statCalc(self):
        self.dialog = Second(self)
        self.dialog.show()
    def FFTFil(self):
        self.dialog = fourierfilter(self)
        self.dialog.show()
    def SinGau (self):
        self.dialog = SinGauWin(self)
        self.dialog.show()
    def MulGau(self):
        self.dialog = MulGauWin(self)
        self.dialog.show()

############# extra windows ######################
        
class ManCalc(QtGui.QDialog):# a second window that opens up to define which charge states and subunit mass to find

    
    def __init__(self, parent=None):
        super(ManCalc, self).__init__(parent)
        self.setGeometry(50, 50, 500, 200)
        self.setWindowTitle("Manual Charge State and Subunit Mass")
        self.inputlowchar = QtGui.QTextEdit()
        self.inputlowchar.setFixedSize(100,25)
        self.inputlowchar.setTabChangesFocus(True)
        self.inputhighchar = QtGui.QTextEdit()
        self.inputhighchar.setFixedSize(100,25)
        self.inputhighchar.setTabChangesFocus(True)
        self.inputSM = QtGui.QTextEdit()
        self.inputSM.setFixedSize(100,25)
        self.inputSM.setTabChangesFocus(True)
        self.inputlowchartag = QtGui.QLabel()
        self.inputlowchartag.setText('Low charge state')
        self.inputlowchartag.setFixedSize(300,25)
        self.inputhighchartag = QtGui.QLabel()
        self.inputhighchartag.setText('high charge state')
        self.inputhighchartag.setFixedSize(300,25)
        self.inputSMtag = QtGui.QLabel()
        self.inputSMtag.setText('Sub-Unit mass (number)')
        self.inputSMtag.setFixedSize(300,25)
        self.button1 = QtGui.QPushButton('Enter')
        self.button1.clicked.connect(self.inputs)
        self.button1.setFixedSize(300,25)
        

        
        layout = QtGui.QGridLayout()
        layout.addWidget(self.lowendtexttag,0,0)
        layout.addWidget(self.inputlowchar,1,0)
        layout.addWidget(self.Highendtexttag,2,0)
        layout.addWidget(self.inputhighchar,3,0)
        layout.addWidget(self.pctpkhttexttag,4,0)
        layout.addWidget(self.inputSM,5,0)
        layout.addWidget(self.button1,6,0)

        self.setLayout(layout)

    def inputs(self):
        lowcharge = int(str(self.inputlowchar.toPlainText())) 
        highcharge = int(str(self.inputhighchar.toPlainText()))
        MW.submass = int(str(self.inputSM.toPlainText()))
        MW.chargestatesr = np.arange(lowcharge,highcharge+1)
        MW.refmaxtab = GuiTestFun.inputmax(MW.chargestatesr,MW.submass,MW.ABFT,MW.ftx)
        MW.plotDots(self)
        self.close()

class Second(QtGui.QDialog):

    
    def __init__(self, parent=None):
        super(Second, self).__init__(parent)
        self.setGeometry(50, 50, 500, 200)
        self.setWindowTitle("iFAMS v. 5.1 Statistical Analyzer")
        self.inputchar = QtGui.QTextEdit()
        self.inputchar.setFixedSize(100,25)
        self.inputchar.setTabChangesFocus(True)
        self.inputSM = QtGui.QTextEdit()
        self.inputSM.setFixedSize(100,25)
        self.inputSM.setTabChangesFocus(True)        
        self.inputBM = QtGui.QTextEdit()
        self.inputBM.setFixedSize(100,25) 
        self.inputBM.setTabChangesFocus(True)
        self.lowendtexttag = QtGui.QLabel()
        self.lowendtexttag.setText('Charge State)')
        self.lowendtexttag.setFixedSize(300,25)
        self.pctpkhttexttag = QtGui.QLabel()
        self.pctpkhttexttag.setText('Sub-Unit mass')
        self.pctpkhttexttag.setFixedSize(300,25)
        self.deltatexttag = QtGui.QLabel()
        self.deltatexttag.setText('Base Mass')
        self.deltatexttag.setFixedSize(300,25)
        self.button1 = QtGui.QPushButton('Calculate')
        self.button1.clicked.connect(self.analyzer)
        self.button1.setFixedSize(300,25)
        self.DiaBox2 = QtGui.QTextEdit()
        

        
        layout = QtGui.QGridLayout()
        layout.addWidget(self.lowendtexttag,0,0)
        layout.addWidget(self.inputchar,1,0)
        layout.addWidget(self.pctpkhttexttag,2,0)
        layout.addWidget(self.inputSM,3,0)
        layout.addWidget(self.deltatexttag,4,0)
        layout.addWidget(self.inputBM,5,0)
        layout.addWidget(self.button1,6,0)
        layout.addWidget(self.DiaBox2,7,0)

        self.setLayout(layout)

    def analyzer(self):
        
        inputcharge = float(str(self.inputchar.toPlainText()))
        inputbasemass = float(str(self.inputBM.toPlainText()))
        inputsubmass = float(str(self.inputSM.toPlainText()))
        avgtotsubunitsdis,stdevlipdis = GuiTestFun.analyzerCalc(self,inputcharge,inputbasemass,inputsubmass)
        atsWord = 'the average total sub-units is '
        stdevWord = 'with a stdev of '
        atsWordfinal = atsWord + avgtotsubunitsdis
        stdevWordfinal = stdevWord + stdevlipdis
        self.DiaBox2.append(atsWordfinal)
        self.DiaBox2.append(stdevWordfinal)

class fourierfilter (QtGui.QDialog):
    
    def __init__(self, parent=None):
        super(fourierfilter, self).__init__(parent)
        self.setGeometry(50, 50, 500, 200)
        self.setWindowTitle("iFAMS v. 5.1 Fourier Filter")
        
        self.inputOTnum = QtGui.QTextEdit()
        self.inputOTnum.setFixedSize(100,25)
        self.inputOTnum.setTabChangesFocus(True)
        self.OTnumtag = QtGui.QLabel()
        self.OTnumtag.setText('Number of Overtones used')
        self.OTnumtag.setFixedSize(300,25)
        
        self.inputZEROFREQnum = QtGui.QTextEdit()
        self.inputZEROFREQnum.setFixedSize(100,25)
        self.inputZEROFREQnum.setTabChangesFocus(True)
        self.ZEROFREQnumtag = QtGui.QLabel()
        self.ZEROFREQnumtag.setText('zero frequency data')
        self.ZEROFREQnumtag.setFixedSize(300,25)
        
        self.button1 = QtGui.QPushButton('Calculate')
        self.button1.clicked.connect(self.Filter)
        self.button1.setFixedSize(300,25)
        
        layout = QtGui.QGridLayout()
        layout.addWidget(self.OTnumtag,0,0)
        layout.addWidget(self.inputOTnum,1,0)
        layout.addWidget(self.ZEROFREQnumtag,2,0)
        layout.addWidget(self.inputZEROFREQnum,3,0)
        layout.addWidget(self.button1,4,0)
        self.setLayout(layout)
        
    
    def Filter(self):
        MW.plotMS.clear()
        ZFreqData = float(str(self.inputZEROFREQnum.toPlainText()))
        OTnum = int(str(self.inputOTnum.toPlainText()))
        MW.reconstspec, MW.reconstbaseline = GuiTestFun.FFTFilter(MW.expandedspan,MW.submass,ZFreqData,MW.ftx,
                                                                  MW.ftspacing,MW.FT,MW.chargestatesr,OTnum)
        FiltDataName = "Fourier Filtered Spectrum"
        BaselineName = "Fourier Baseline"
        BaselineSubName = "Baseline Subtracted Data"
        MW.plotMS.plot(MW.xdata,MW.ydata, pen ='k',symbol=None)
        MW.plotMS.plot(MW.xnew,MW.reconstspec[0:int(len(MW.xnew))],
                       pen = pg.mkPen(color = 'r', symbol = None, width=3), name = FiltDataName, symbol=None)
        MW.plotMS.plot(MW.xnew,MW.reconstbaseline[0:int(len(MW.xnew))],
                       pen = pg.mkPen(color = 'b', symbol = None, width=3),name = BaselineName, symbol=None)
        MW.plotMS.plot(MW.xnew,MW.ynew-MW.reconstbaseline[0:int(len(MW.xnew))],
                       pen='g', name = BaselineSubName, symbol=None)
        self.SaveFilter()
        self.close()
    
    def SaveFilter(self):
        FIltString1 = "Fourier_Filtered_Spectrum"
        FIltString2 = "Fourier_Baseline"
        FIltString3 = "Baseline_Subtracted_Data"
        filenameFil1 = FIltString1 + ".csv"
        filenameFil2 = FIltString2 + ".csv"
        filenameFil3 = FIltString3 + ".csv"
        filforexport1 = np.transpose([MW.xnew,MW.reconstspec[0:int(len(MW.xnew))]])
        filforexport2 = np.transpose([MW.xnew,MW.reconstbaseline[0:int(len(MW.xnew))]])
        filforexport3 = np.transpose([MW.xnew,MW.ynew-MW.reconstbaseline[0:int(len(MW.xnew))]])
        np.savetxt(filenameFil1,filforexport1,fmt='%10.6f', delimiter=',')
        np.savetxt(filenameFil2,filforexport2,fmt='%10.6f', delimiter=',')
        np.savetxt(filenameFil3,filforexport3,fmt='%10.6f', delimiter=',')
        
        
############################################################################
################     Single Gaussian Window    #############################
############################################################################



class SinGauWin(QtGui.QDialog):

    
    def __init__(self, parent=None):
        super(SinGauWin, self).__init__(parent)
        self.setGeometry(50, 50, 500, 200)
        self.setWindowTitle("Single Charge State Gaussian")
        QtGui.QApplication.setStyle(QtGui.QStyleFactory.create("Cleanlooks"))
        
###############input gui####################
        self.input_charge = QtGui.QTextEdit()
        self.input_charge.setFixedSize(100,25)
        self.input_charge.setTabChangesFocus(True)
        
        
        self.input_min_subunit_number = QtGui.QTextEdit()
        self.input_min_subunit_number.setFixedSize(100,25)
        self.input_min_subunit_number.setTabChangesFocus(True)
        
        self.input_max_subunit_number = QtGui.QTextEdit()
        self.input_max_subunit_number.setFixedSize(100,25)
        self.input_max_subunit_number.setTabChangesFocus(True)
        
        self.input_subunit_mass = QtGui.QTextEdit()
        self.input_subunit_mass.setFixedSize(100,25)
        self.input_subunit_mass.setTabChangesFocus(True)
        
        self.input_peak_stdev = QtGui.QTextEdit()
        self.input_peak_stdev.setFixedSize(100,25)
        self.input_peak_stdev.setTabChangesFocus(True)
        
        self.input_basemass = QtGui.QTextEdit()
        self.input_basemass.setFixedSize(100,25)
        self.input_basemass.setTabChangesFocus(True)
###############input gui####################       
        
        self.input_charge_tag = QtGui.QLabel()
        self.input_charge_tag.setText('charge state')
        self.input_charge_tag.setFixedSize(300,25)
        
        
        self.input_min_subunit_number_tag = QtGui.QLabel()
        self.input_min_subunit_number_tag.setText('min number of subunits')
        self.input_min_subunit_number_tag.setFixedSize(300,25)
        
        self.input_max_subunit_number_tag = QtGui.QLabel()
        self.input_max_subunit_number_tag.setText('max number of subunits')
        self.input_max_subunit_number_tag.setFixedSize(300,25)
        
        self.input_subunit_mass_tag = QtGui.QLabel()
        self.input_subunit_mass_tag.setText('subunit mass')
        self.input_subunit_mass_tag.setFixedSize(300,25)
        
        
        self.input_peak_stdev_tag = QtGui.QLabel()
        self.input_peak_stdev_tag.setText('peak stdev')
        self.input_peak_stdev_tag.setFixedSize(300,25)
        
        self.input_basemass_tag = QtGui.QLabel()
        self.input_basemass_tag.setText('basemass')
        self.input_basemass_tag.setFixedSize(300,25)
        
        self.button1 = QtGui.QPushButton('plot model spectrum')
        self.button1.clicked.connect(self.SinGauAnalyzer)
        self.button1.setFixedSize(300,25)
        
        self.progress = QtGui.QProgressBar(self)
        
        self.progress_tag = QtGui.QLabel()
        self.progress_tag.setText('Progress')
        self.progress_tag.setFixedSize(300,25)
        
        

        
        layout = QtGui.QGridLayout()
        layout.addWidget(self.input_charge_tag,0,0)
        layout.addWidget(self.input_charge,1,0)
        layout.addWidget(self.input_subunit_mass_tag,3,0)
        layout.addWidget(self.input_subunit_mass,4,0)
        layout.addWidget(self.input_min_subunit_number_tag,5,0)
        layout.addWidget(self.input_min_subunit_number,6,0)
        layout.addWidget(self.input_max_subunit_number_tag,7,0)
        layout.addWidget(self.input_max_subunit_number,8,0)
        layout.addWidget(self.button1,9,0)
        layout.addWidget(self.input_peak_stdev_tag,0,1)
        layout.addWidget(self.input_peak_stdev,1,1)
        layout.addWidget(self.input_basemass_tag,2,1)
        layout.addWidget(self.input_basemass,3,1)
        layout.addWidget(self.progress_tag,4,1)
        layout.addWidget(self.progress,5,1)
        
        

        self.setLayout(layout)
    
    def SinGauAnalyzer(self):
        charge=float(str(self.input_charge.toPlainText()))
        lipidH=float(str(self.input_max_subunit_number.toPlainText()))
        lipidL=float(str(self.input_min_subunit_number.toPlainText()))
        subunitM = float(str(self.input_subunit_mass.toPlainText()))
        peakstdev = float(str(self.input_peak_stdev.toPlainText()))
        basemass = float(str(self.input_basemass.toPlainText()))
        data,datax,lipidnumber,centroidE,lipidstd = GuiTestFun.SinGauAnalyzerCalc(charge,lipidH,lipidL,subunitM,
                                                                                  peakstdev,basemass)
        for i in range (0,len(data)):
            for k in range (0,len(lipidnumber)):
                data[i] += np.exp(-(i-centroidE/charge)**2/(2*(lipidstd/(2*charge))**2))*np.exp(-(i-((basemass + subunitM*lipidnumber[k])/charge))**2/(2*peakstdev**2))
                self.completed = i/len(data)*100
                self.progress.setValue(self.completed)
        MW.plotMS.clear()
        MW.plotMS.plot(datax,data,pen ='k',symbol=None)
        MW.plotMS.show()
        
        datarev = data[::-1]
        datamirror = np.append(data,datarev)
        newx = np.arange(1,(2*(len(datax))+1))           
        ftdata = np.fft.fft(datamirror)
        absftdata = abs(ftdata)
        MW.plotFT.clear()
        MW.plotFT.plot(newx,absftdata,pen ='k',symbol=None)
        MW.plotFT.show()

class MulGauWin(QtGui.QDialog):

    
    def __init__(self, parent=None):
        super(MulGauWin, self).__init__(parent)
        self.setGeometry(50, 50, 500, 200)
        self.setWindowTitle("Multiple Charge States Gaussian")
        QtGui.QApplication.setStyle(QtGui.QStyleFactory.create("Cleanlooks"))
        
###############input gui####################
        self.input_low_charge = QtGui.QTextEdit()
        self.input_low_charge.setFixedSize(100,25)
        self.input_low_charge.setTabChangesFocus(True)
        
        self.input_high_charge = QtGui.QTextEdit()
        self.input_high_charge.setFixedSize(100,25) 
        self.input_high_charge.setTabChangesFocus(True)
        
        self.input_min_subunit_number = QtGui.QTextEdit()
        self.input_min_subunit_number.setFixedSize(100,25)
        self.input_min_subunit_number.setTabChangesFocus(True)
        
        self.input_max_subunit_number = QtGui.QTextEdit()
        self.input_max_subunit_number.setFixedSize(100,25)
        self.input_max_subunit_number.setTabChangesFocus(True)
        
        self.input_subunit_mass = QtGui.QTextEdit()
        self.input_subunit_mass.setFixedSize(100,25)
        self.input_subunit_mass.setTabChangesFocus(True)
        
        self.input_population_stdev = QtGui.QTextEdit()
        self.input_population_stdev.setFixedSize(100,25)
        self.input_population_stdev.setTabChangesFocus(True)
        
        self.input_peak_stdev = QtGui.QTextEdit()
        self.input_peak_stdev.setFixedSize(100,25)
        self.input_peak_stdev.setTabChangesFocus(True)
        
        self.input_basemass = QtGui.QTextEdit()
        self.input_basemass.setFixedSize(100,25)
        self.input_basemass.setTabChangesFocus(True)
        
        self.input_DiffInSub = QtGui.QTextEdit()
        self.input_basemass.setFixedSize(100,25)
        self.input_basemass.setTabChangesFocus(True)
###############input gui####################       

########### Tags and Progress Bar ##########       
        
        self.input_low_charge_tag = QtGui.QLabel()
        self.input_low_charge_tag.setText('charge state min')
        self.input_low_charge_tag.setFixedSize(300,25)
        
        self.input_high_charge_tag = QtGui.QLabel()
        self.input_high_charge_tag.setText('charge state max')
        self.input_high_charge_tag.setFixedSize(300,25)
        
        self.input_min_subunit_number_tag = QtGui.QLabel()
        self.input_min_subunit_number_tag.setText('min number of subunits')
        self.input_min_subunit_number_tag.setFixedSize(300,25)
        
        self.input_max_subunit_number_tag = QtGui.QLabel()
        self.input_max_subunit_number_tag.setText('max number of subunits')
        self.input_max_subunit_number_tag.setFixedSize(300,25)
        
        self.input_subunit_mass_tag = QtGui.QLabel()
        self.input_subunit_mass_tag.setText('subunit mass')
        self.input_subunit_mass_tag.setFixedSize(300,25)
        
        self.input_population_stdev_tag = QtGui.QLabel()
        self.input_population_stdev_tag.setText('population stdev')
        self.input_population_stdev_tag.setFixedSize(300,25)
        
        self.input_peak_stdev_tag = QtGui.QLabel()
        self.input_peak_stdev_tag.setText('peak stdev')
        self.input_peak_stdev_tag.setFixedSize(300,25)
        
        self.input_basemass_tag = QtGui.QLabel()
        self.input_basemass_tag.setText('basemass')
        self.input_basemass_tag.setFixedSize(300,25)
        
        self.button1 = QtGui.QPushButton('plot model spectrum')
        self.button1.clicked.connect(self.MulGauAnalyzer)
        self.button1.setFixedSize(300,25)

        self.button2 = QtGui.QPushButton('save model spectrum')
        self.button2.clicked.connect(self.saveMulGauAnalyzer)
        self.button2.setFixedSize(300,25)
        
        self.progress = QtGui.QProgressBar(self)
        
        self.progress_tag = QtGui.QLabel()
        self.progress_tag.setText('Progress')
        self.progress_tag.setFixedSize(300,25)
        
        self.DifSubNum = QtGui.QCheckBox("Differing Subunits?")
        
        self.input_DiffInSub_tag = QtGui.QLabel()
        self.input_DiffInSub_tag.setText('# of Subunits per Charge differ by?')
        self.input_DiffInSub_tag.setFixedSize(300,25)
########### Tags and Progress Bar ##########       

############ Window Layout #################        

        layout = QtGui.QGridLayout()
        layout.addWidget(self.input_low_charge_tag,0,0)
        layout.addWidget(self.input_low_charge,1,0)
        layout.addWidget(self.input_high_charge_tag,2,0)
        layout.addWidget(self.input_high_charge,3,0)
        layout.addWidget(self.input_subunit_mass_tag,4,0)
        layout.addWidget(self.input_subunit_mass,5,0)
        layout.addWidget(self.input_min_subunit_number_tag,6,0)
        layout.addWidget(self.input_min_subunit_number,7,0)
        layout.addWidget(self.input_max_subunit_number_tag,8,0)
        layout.addWidget(self.input_max_subunit_number,9,0)
        layout.addWidget(self.button1,10,0)
        layout.addWidget(self.button2,11,0)
        layout.addWidget(self.input_population_stdev_tag,0,1)
        layout.addWidget(self.input_population_stdev,1,1)
        layout.addWidget(self.input_peak_stdev_tag,2,1)
        layout.addWidget(self.input_peak_stdev,3,1)
        layout.addWidget(self.input_basemass_tag,4,1)
        layout.addWidget(self.input_basemass,5,1)
        layout.addWidget(self.progress_tag,6,1)
        layout.addWidget(self.progress,7,1)
        layout.addWidget(self.DifSubNum,8,1)
        layout.addWidget(self.input_DiffInSub_tag,9,1)
        layout.addWidget(self.input_DiffInSub,10,1)
        

        self.setLayout(layout)

############ Window Layout #################    

    def MulGauAnalyzer(self): #The Analysis functions for Multiple Gaussian Spectra Assembler
        
        #######inputs########
        chargeH = float(str(self.input_high_charge.toPlainText()))
        chargeL = float(str(self.input_low_charge.toPlainText()))
        lipidH=float(str(self.input_max_subunit_number.toPlainText()))
        lipidL=float(str(self.input_min_subunit_number.toPlainText()))
        subunitM = float(str(self.input_subunit_mass.toPlainText()))
        stdevT = float(str(self.input_population_stdev.toPlainText()))
        peakstdev = float(str(self.input_peak_stdev.toPlainText()))
        basemass = float(str(self.input_basemass.toPlainText()))
        charge,lipidnumber,lipidstd,centroidT,self.data,self.datax,centroidE = GuiTestFun.MulGauAnalyzerCalc(chargeH,
                                                                                                             chargeL,
                                                                                                             lipidH,
                                                                                                             lipidL,
                                                                                                             subunitM,
                                                                                                             basemass)
        
        if self.DifSubNum.isChecked() == True:
            SubDif = float(str(self.input_DiffInSub.toPlainText()))
            AvgChar = (chargeH+chargeL)/2
            CharDif = chargeH-AvgChar
            centroidT =(((((lipidH-CharDif*SubDif)+(lipidL-CharDif*SubDif))/2)*subunitM)+basemass)/((chargeH+chargeL)/2)
            for i in range (0,len(self.data)):
                for j in range (0,len(charge)):
                    lipidLnew = lipidL-((chargeH-charge[j])*SubDif)
                    lipidHnew = lipidH-((chargeH-charge[j])*SubDif)
                    lipidnumber = np.arange(lipidLnew,lipidHnew+1)
                    centroidE = ((((lipidHnew+lipidLnew))/2)*subunitM)+basemass
                    for k in range (0,len(lipidnumber)):
                        self.data[i] += np.exp(-(i-centroidT)**2/(2*stdevT**2))*np.exp(-(i-centroidE/charge[j])**2/(2*(lipidstd/(2*charge[j]))**2))*np.exp(-(i-((basemass + subunitM*lipidnumber[k])/charge[j]))**2/(2*peakstdev**2))
                        self.completed = i/len(self.data)*100
                        self.progress.setValue(self.completed)

            noise = np.random.normal(0,0.05,len(self.data))
            for i in range(0,len(self.data)):
                self.data[i]=self.data[i]+noise[i]
        else:
            for i in range (0,len(data)):
                for j in range (0,len(charge)):
                    for k in range (0,len(lipidnumber)):
                        self.data[i] += np.exp(-(i-centroidT)**2/(2*stdevT**2))*np.exp(-(i-centroidE/charge[j])**2/(2*(lipidstd/(2*charge[j]))**2))*np.exp(-(i-((basemass + subunitM*lipidnumber[k])/charge[j]))**2/(2*peakstdev**2))
                        self.completed = i/len(data)*100
                        self.progress.setValue(self.completed)
        MW.plotMS.clear()
        MW.plotMS.plot(self.datax,self.data,pen ='k',symbol=None)
        MW.plotMS.show()
        
        datarev = self.data[::-1]
        datamirror = np.append(self.data,datarev)
        newx = np.arange(1,(2*(len(self.datax))+1))
        ftdata = np.fft.fft(datamirror)
        absftdata = abs(ftdata)
        MW.plotFT.clear()
        MW.plotFT.plot(newx,absftdata,pen ='k',symbol=None)
        MW.plotFT.show()

    def saveMulGauAnalyzer(self):
        ftstring = "Model_Spectrum"
        ftfilename = ftstring + ".csv"
        ftarrayforexport = np.transpose([self.datax,self.data])
        np.savetxt(ftfilename,ftarrayforexport,fmt='%10.6f',delimiter=',')


class SquaredDif(QtGui.QDialog):
    self = 0
        
def main():
    app = QtGui.QApplication(sys.argv)
    form = MW()
    form.show()
    app.exec_()

if __name__ == "__main__":
    main()